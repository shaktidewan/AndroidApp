package com.example.quarentine_fitness;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    String [] data ={"asd","asd","asd","asd","asd","asd","asd"};
    ListView one;
    BottomNavigationView bottomnav;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        one =findViewById(R.id.lv_id);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.list_item, R.id.textView2,data);
        one.setAdapter(adapter);


        bottomnav = findViewById(R.id.bottom__id);
        bottomnav.setOnNavigationItemSelectedListener(navListner);

        getSupportFragmentManager().beginTransaction().replace(R.id.frame_id, new HomeFrag()).commit();
    }

    BottomNavigationView.OnNavigationItemSelectedListener navListner = new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

            Fragment selectedFragment = null;
            switch (menuItem.getItemId()) {

                case R.id.home_id:
                    selectedFragment = new HomeFrag();
                    break;

                case R.id.video_id:
                    selectedFragment = new VideoFrag();
                    break;

                case R.id.setting_id:
                    selectedFragment = new SettingFrag();
                    break;

            }
            getSupportFragmentManager().beginTransaction().replace(R.id.frame_id, selectedFragment).commit();
            // aaba fragment lai display garne code
            return true;
        }
    };


}